"""In Key,
•Enter an 'integer' for Caeser Cipher.
•Enter any 'word' for Vigenère Cipher.
•Enter any 'Hashing algorithm' like 'sha1 or md5 or sha384 etc.' for Hashing"""


def caeser_cipher(text: str, key: int) -> str:
    """Caeser ciphers the plain 'text' by using the supplied 'key'.
        In a caeser cipher, each character of the plain text is shifted by the provided int value
        | Example: caeser_cipher('rayyan',-1)
        | Output: 'q'xx'm
        Its typically based on ascii char set"""
    cipher = int(key)
    list=[]
    char=[]

    for num in text:
        list.append(ord(num)+cipher)
    for i in list:
        char.append(chr(i))

    return ''.join(char)



def Hash(text: object, algorithm: str) -> str:
    """Returns the hashed-text of the supplied text, using the supplied algorithm."""
    import hashlib

    key = str(algorithm)

    if key == 'sha1':
        hash_object = hashlib.sha1(text.encode())
    elif key == 'sha256' or key == 'sha2':
        hash_object = hashlib.sha256(text.encode())
    elif key == 'sha224':
        hash_object = hashlib.sha224(text.encode())
    elif key == 'sha384':
        hash_object = hashlib.sha384(text.encode())
    elif key == 'md5':
        hash_object = hashlib.md5(text.encode())
    elif key == 'sha512':
        hash_object = hashlib.sha512(text.encode())
    else:
        hash_object = hashlib.sha1(text.encode())

    enc_txt = hash_object.hexdigest()


def vigenere(text: str, key: str) -> str:
    """Returns the Vigenère Ciphered text of the supplied text, using the provided key.
    Special characters and integers are not allowed as the 'key'.
    Special characters and integers in text are ignored while being encrypted.
    | Example: vigenere(Rayyan_Nafees+-931,rock).
    | Output: Ioairb_Xrtgoj+-931."""

    alpha = 'abcdefghijklmnopqrstuvwxyz'
    Alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    for char in key :
        if char not in Alpha and alpha:
            list(key).remove(char)

    text_list = list(text)

    key = str(key)
    text = ''.join(text_list)

    key2 = key*(len(text)//len(key))
    remainder = len(text) % len(key)

    key_list = list(key2)            #These 5 lines along are mind blogging and complicated..

    for i in range(remainder):
        key_list.append(key_list[i])

    Key = ''.join(key_list)          #Till Here.

    enc = []                        #contains the indexed text or symbol

    for i in range(len(text)):
        if text[i] in Alpha:
            enc.append(Alpha[ Alpha.index(text[i]) + Alpha.index(Key[i].upper()) - len(Alpha) ])
        elif text[i] in alpha:
            enc.append(alpha[ alpha.index(text[i]) + alpha.index(Key[i].lower()) - len(alpha) ])
        else:
            enc.append(text[i])
        
    return ''.join(enc)
