from setuptools import setup 
 
setup(name = "encrypt",
version = "1.0",
description = "Encrypts text in general formats (like cipher and Hash).",
author = "Rayyan",
author_email = "nafees.rayyan@gmail.com",
py_modules = ["encrypt"],)
