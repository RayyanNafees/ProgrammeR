from setuptools import setup 
 
sdict = {'name': 'g', 'version': 'g', 'description': 'g', 'author': 'g', 'author_email': 'g', 'url': 'g', 'py_modules': ['encrypt']}
setup(**sdict)