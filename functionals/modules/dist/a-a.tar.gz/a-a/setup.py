from setuptools import setup 
 
sdict = {'name': 'a', 'version': 'a', 'description': 'a', 'author': 'a', 'author_email': 'a', 'url': 'a', 'py_modules': ['encrypt']}
setup(**sdict)